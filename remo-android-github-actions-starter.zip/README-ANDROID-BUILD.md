# Remo Android APK build starter

This folder is a starter Android Gradle project using the Kotlin source files from the Remo ZIP. It is not yet a complete voice assistant: the current MainActivity is a setup screen, and voice capture, speaker verification SDK, backend URL/token configuration, and UI-to-RemoBrain wiring still need implementation.

## Phone-only GitHub Actions build
1. Download and extract this ZIP on your phone using Android Files / another archive manager.
2. Open your existing GitHub `Remo` repository in Chrome and switch to Desktop site if needed.
3. Upload the files and folders from this ZIP to the repository root. Keep the existing `backend/` and original `android/` folders if they already exist. Upload `.github/workflows/android-apk.yml` too; enable “show hidden files” if your file manager hides `.github`.
4. Commit the files to `main` (or `master`).
5. Open the repository's Actions tab, select “Build Remo Android APK”, and run workflow if it did not start automatically.
6. Open the successful run, scroll to Artifacts, and download `Remo-debug-apk`. Extract that downloaded artifact and install `app-debug.apk` on your phone.

## Notes
- This builds a debug/test APK, not a Play Store release.
- Do not commit API keys or `.env` files. Put backend secrets on the server only.
- Accessibility and notification access are powerful permissions. Enable them only if you understand and need those features.
- The Kotlin voice lock contains a verifier interface but no real voice-verification implementation. Do not treat it as secure voice authentication until a verifier is implemented and tested.
