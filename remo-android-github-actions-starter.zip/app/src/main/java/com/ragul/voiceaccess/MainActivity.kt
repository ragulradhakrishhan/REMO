package com.ragul.voiceaccess

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** Starter screen. Voice input/backend connection still needs to be wired in. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "Remo"
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Kotlin Android starter installed successfully.

Next: configure your HTTPS backend and connect voice input.

Accessibility and notification access are optional and must be enabled manually in Android Settings."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        })
        setContentView(root)
    }
}
