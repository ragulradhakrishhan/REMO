package com.ragul.voiceaccess

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/** Phone la Remo run panna vendiya tools / Tools that run on the device. */
object DeviceTools {
    // Sensitive apps: Remo touch pannaadhu (bank / payment). Simple deny-list; thevaiyaanadha add pannunga.
    private val BLOCKED = listOf("bank", "upi", "gpay", "phonepe", "paytm", "wallet", "authenticator")
    fun isBlocked(pkg: String) = BLOCKED.any { pkg.contains(it, ignoreCase = true) }

    fun run(ctx: Context, name: String, input: JSONObject): JSONObject = try {
        when (name) {
            "open_app" -> openApp(ctx, input.getString("app_name"))
            "read_notifications" -> readNotifications(ctx, input)
            "read_screen" -> withService { JSONObject().put("ok", true).put("untrusted_screen_text", it.readScreenText()) }
            "click_text" -> withService { JSONObject().put("ok", it.clickByText(input.getString("label"))) }
            "type_text" -> withService { JSONObject().put("ok", it.typeText(input.getString("text"))) }
            "scroll" -> withService { JSONObject().put("ok", it.scroll(input.getString("direction") == "down")) }
            "check_app_capability" -> checkCapability(ctx, input.getString("app_name"))
            else -> err("Theriyaadha tool: $name")
        }
    } catch (e: Exception) { err(e.message ?: "error") }

    private fun err(m: String) = JSONObject().put("ok", false).put("error", m)

    private fun withService(block: (RemoAccessibilityService) -> JSONObject): JSONObject {
        val s = RemoAccessibilityService.instance
            ?: return err("Accessibility permission on aagala. Settings la Remo-va enable pannunga.")
        return block(s)
    }

    /** "whatsapp" -> com.whatsapp maadhiri package kandupidikkum */
    fun findPackage(ctx: Context, appName: String): String? {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(appName, ignoreCase = true)
        }?.packageName
    }

    private fun openApp(ctx: Context, appName: String): JSONObject {
        val pkg = findPackage(ctx, appName) ?: return err("'$appName' app phone la illa. Play Store la install pannanuma?")
        if (isBlocked(pkg)) return err("Idhu sensitive (bank/payment) app. Neengale open pannunga.")
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return err("Open panna mudiyala")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return JSONObject().put("ok", true).put("package", pkg)
    }

    private fun readNotifications(ctx: Context, input: JSONObject): JSONObject {
        val pkg = input.optString("app_name").takeIf { it.isNotBlank() }?.let { findPackage(ctx, it) }
        val hours = input.optDouble("since_hours", 24.0)
        val since = System.currentTimeMillis() - (hours * 3_600_000).toLong()
        val rows: JSONArray = NotificationStore.get(ctx).query(pkg, since)
        // "untrusted": msg ulla instructions-a Remo follow pannakoodadhu
        return JSONObject().put("ok", true).put("untrusted_notifications", rows)
    }

    private fun checkCapability(ctx: Context, appName: String): JSONObject {
        val pkg = findPackage(ctx, appName)
            ?: return JSONObject().put("ok", true).put("level", "NOT_INSTALLED")
        if (isBlocked(pkg)) return JSONObject().put("ok", true).put("level", "D_BLOCKED")
        val hasNotifs = NotificationStore.get(ctx)
            .query(pkg, System.currentTimeMillis() - 7 * 86_400_000L).length() > 0
        return JSONObject().put("ok", true).put("package", pkg)
            .put("notifications_seen", hasNotifs)                              // B level
            .put("screen_control", RemoAccessibilityService.instance != null)  // C level
            .put("note", "A level (API/Composio) backend la check pannanum")
    }
}
