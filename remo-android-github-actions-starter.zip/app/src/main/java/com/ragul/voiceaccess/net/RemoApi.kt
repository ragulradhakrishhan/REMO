package com.ragul.voiceaccess.net

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

/**
 * Backend ku pesura chinna client. API key inga illa, backend la mattum.
 * Small client for the Remo backend. The Anthropic key never lives in the app.
 * baseUrl = HTTPS kandippa (production la). token = EncryptedSharedPreferences la store pannunga.
 */
class RemoApi(private val baseUrl: String, private val token: String) {
    private val http = OkHttpClient()
    private val json = "application/json".toMediaType()

    // Blocking call: Dispatchers.IO la call pannunga
    fun post(path: String, body: JSONObject): JSONObject {
        val req = Request.Builder()
            .url(baseUrl + path)
            .header("x-remo-token", token)
            .post(body.toString().toRequestBody(json))
            .build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("API ${r.code}")
            return JSONObject(r.body!!.string())
        }
    }
}
