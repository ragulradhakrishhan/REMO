// Remo web client: Laptop browser, Android Chrome, iOS Safari la work aagum.
// (OS-level control illa; adhukku Android native app venum.)
const $ = (id) => document.getElementById(id);
let messages = [];
let lang = 'ta-IN'; // pesura language: ta-IN / en-IN

const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
if (!SR) $('status').textContent = 'Indha browser la voice support illa. Chrome / Safari use pannunga.';

function setState(s, text) {
  $('remo').className = s;
  if (text) $('status').textContent = text;
}
function addMsg(who, text) {
  const d = document.createElement('div');
  d.className = 'msg ' + (who === 'you' ? 'you' : 'remo');
  d.textContent = text; // textContent = XSS safe
  $('log').appendChild(d);
  d.scrollIntoView({ behavior: 'smooth' });
}
function token() {
  let t = localStorage.getItem('remoToken');
  if (!t) { t = prompt('Device token (.env la REMO_DEVICE_TOKEN):') || ''; localStorage.setItem('remoToken', t); }
  return t;
}
async function api(path, body) {
  const r = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-remo-token': token() },
    body: JSON.stringify(body),
  });
  if (r.status === 401) { localStorage.removeItem('remoToken'); throw new Error('Token thappu'); }
  if (!r.ok) throw new Error('API ' + r.status);
  return r.json();
}

// Tanglish reply-a en-IN voice padikkum (Roman letters). Natural Tamil voice venumna Cloud TTS use pannalam.
function say(text) {
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = 'en-IN';
  const voices = speechSynthesis.getVoices().filter((v) => v.lang === 'en-IN');
  u.voice = voices.find((v) => /male/i.test(v.name) && !/female/i.test(v.name)) || voices[0] || null;
  u.onstart = () => setState('speaking', 'Remo pesuthu...');
  u.onend = () => setState('idle', 'Mic-a thotthu pesunga');
  speechSynthesis.speak(u);
}

// Web la device tools illa; server tools mattum (confirm oda)
async function runPending(p) {
  if (!p.server) return { ok: false, error: `Indha web version la "${p.name}" support illa. Android app venum.` };
  if (p.needsConfirm && !confirm(`Remo: "${p.name}" pannattuma?\n${JSON.stringify(p.input)}`)) {
    return { ok: false, error: 'User cancel pannitanga' };
  }
  return api('/api/tools/run', { name: p.name, input: p.input, confirmed: true });
}

function trimHistory() { // tool_use / tool_result pair udaiyaama trim
  if (messages.length <= 40) return;
  const from = messages.length - 30;
  const i = messages.findIndex((m, idx) => idx >= from && m.role === 'user' && typeof m.content === 'string');
  if (i > 0) messages = messages.slice(i);
}

async function ask(text) {
  try {
    setState('thinking', 'Yosikkuren...');
    trimHistory();
    messages.push({ role: 'user', content: text });
    let data = await api('/api/chat', { messages });
    while (!data.done) {
      messages = data.messages;
      const blocks = [...data.results];
      for (const p of data.pending) {
        blocks.push({ type: 'tool_result', tool_use_id: p.id, content: JSON.stringify(await runPending(p)) });
      }
      messages.push({ role: 'user', content: blocks });
      data = await api('/api/chat', { messages });
    }
    messages = data.messages;
    addMsg('remo', data.reply);
    say(data.reply);
  } catch (e) {
    setState('idle', 'Error: ' + e.message);
  }
}

let rec = null;
function listen() {
  if (!SR) return;
  rec = new SR();
  rec.lang = lang;
  rec.interimResults = false;
  rec.onstart = () => setState('listening', 'Kekkuren...');
  rec.onerror = (e) => setState('idle', 'Mic error: ' + e.error);
  rec.onend = () => { if ($('remo').className === 'listening') setState('idle', 'Mic-a thotthu pesunga'); };
  rec.onresult = async (ev) => {
    const said = ev.results[0][0].transcript;
    let shown = said;
    if (lang === 'ta-IN') { // Tamil எழுத்து -> Tanglish, type pannura madhiri kaattum
      try { shown = (await api('/api/tanglish', { text: said })).text || said; } catch { /* original-a kaattu */ }
    }
    addMsg('you', shown);
    ask(said);
  };
  rec.start();
}

$('mic').onclick = () => { speechSynthesis.cancel(); listen(); };
$('lang').onclick = () => {
  lang = lang === 'ta-IN' ? 'en-IN' : 'ta-IN';
  $('lang').textContent = lang === 'ta-IN' ? 'தமிழ்' : 'English';
};
$('tok').onclick = () => { localStorage.removeItem('remoToken'); token(); };
