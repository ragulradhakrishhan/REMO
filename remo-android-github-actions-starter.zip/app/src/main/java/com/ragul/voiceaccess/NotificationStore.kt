package com.ragul.voiceaccess

import android.app.Notification
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

/**
 * Vara notifications-a phone la mattum save pannum ("yaaru msg panna?" ku).
 * TODO: Production la SQLCipher use panni encrypt pannunga.
 */
class NotificationStore private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx.applicationContext, "remo_notifs.db", null, 1) {

    companion object {
        @Volatile private var inst: NotificationStore? = null
        fun get(ctx: Context) = inst ?: synchronized(this) { inst ?: NotificationStore(ctx).also { inst = it } }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE n (id INTEGER PRIMARY KEY AUTOINCREMENT, pkg TEXT, title TEXT, body TEXT, t INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun insert(pkg: String, title: String?, body: String?) {
        val cv = ContentValues().apply {
            put("pkg", pkg); put("title", title); put("body", body); put("t", System.currentTimeMillis())
        }
        writableDatabase.insert("n", null, cv)
        // 7 naal-ku mela pazhasa data delete
        writableDatabase.delete("n", "t < ?", arrayOf((System.currentTimeMillis() - 7 * 86_400_000L).toString()))
    }

    fun query(pkg: String?, since: Long): JSONArray {
        val where = if (pkg != null) "t >= ? AND pkg = ?" else "t >= ?"
        val args = if (pkg != null) arrayOf(since.toString(), pkg) else arrayOf(since.toString())
        val out = JSONArray()
        readableDatabase.query("n", null, where, args, null, null, "t DESC", "50").use { c ->
            while (c.moveToNext()) {
                out.put(JSONObject()
                    .put("app", c.getString(c.getColumnIndexOrThrow("pkg")))
                    .put("title", c.getString(c.getColumnIndexOrThrow("title")))
                    .put("text", c.getString(c.getColumnIndexOrThrow("body")))
                    .put("time", c.getLong(c.getColumnIndexOrThrow("t"))))
            }
        }
        return out
    }
}

/** Notification access Settings la manual-a ON pannanum. */
class RemoNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        if (DeviceTools.isBlocked(sbn.packageName)) return // bank/OTP apps store pannaadhu
        val ex = sbn.notification.extras
        NotificationStore.get(this).insert(
            sbn.packageName,
            ex.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
            ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        )
    }
}
