package com.ragul.voiceaccess

import android.content.Context
import com.ragul.voiceaccess.net.RemoApi
import com.ragul.voiceaccess.security.VoiceGuard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Remo-oda brain loop (web app.js maadhiri).
 * Flow: text -> backend (Claude) -> tools -> reply.
 * - Server tools (notes, composio) backend run pannum
 * - Device tools (open_app, read_screen...) inga DeviceTools run pannum
 * - Delete / composio: confirm kandippa, UI la voice verify + confirm pannunga
 */
class RemoBrain(
    private val ctx: Context,
    private val api: RemoApi,
    private val guard: VoiceGuard
) {
    private var messages = JSONArray()

    /** confirm(msg): UI la "pannattuma?" nu kettu, voice verify pannitu true/false kudukkanum */
    suspend fun ask(text: String, confirm: suspend (String) -> Boolean): String = withContext(Dispatchers.IO) {
        // Ovvoru command munnadiyum session check (VoiceGuard)
        if (!guard.isSessionValid()) return@withContext "Lock aagi irukku. 'Hey Remo' nu sollunga."

        messages.put(JSONObject().put("role", "user").put("content", text))
        var data = api.post("/api/chat", JSONObject().put("messages", messages))

        while (!data.getBoolean("done")) {
            messages = data.getJSONArray("messages")
            val blocks = JSONArray()
            val auto = data.getJSONArray("results")
            for (i in 0 until auto.length()) blocks.put(auto.getJSONObject(i))

            val pending = data.getJSONArray("pending")
            for (i in 0 until pending.length()) {
                val p = pending.getJSONObject(i)
                val name = p.getString("name")
                val input = p.getJSONObject("input")
                val result: JSONObject = when {
                    p.getBoolean("server") -> {
                        if (p.getBoolean("needsConfirm") && !confirm("$name pannattuma? $input"))
                            JSONObject().put("ok", false).put("error", "User cancel pannitanga")
                        else api.post("/api/tools/run",
                            JSONObject().put("name", name).put("input", input).put("confirmed", true))
                    }
                    else -> DeviceTools.run(ctx, name, input)
                }
                blocks.put(JSONObject()
                    .put("type", "tool_result")
                    .put("tool_use_id", p.getString("id"))
                    .put("content", result.toString()))
            }
            messages.put(JSONObject().put("role", "user").put("content", blocks))
            data = api.post("/api/chat", JSONObject().put("messages", messages))
        }
        messages = data.getJSONArray("messages")
        data.getString("reply")
    }
}
