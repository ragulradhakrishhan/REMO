package com.ragul.voiceaccess.security

import android.content.Context
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Plug your speaker-verification SDK here (Picovoice Eagle / SpeechBrain etc).
 * Return a score 0.0 - 1.0 : how much the audio matches the registered voice.
 */
interface SpeakerVerifier {
    fun score(pcm: ShortArray): Float
}

enum class GuardState { LOCKED_WAITING_WAKE, WAITING_VOICE, UNLOCKED, HARD_LOCKED }

class VoiceGuard(
    context: Context,
    private val verifier: SpeakerVerifier,
    private val onStateChange: (GuardState) -> Unit
) {
    companion object {
        const val MAX_ATTEMPTS = 3
        const val VOICE_THRESHOLD = 0.75f          // tune after testing
        const val SESSION_TIMEOUT_MS = 5 * 60_000L  // auto re-lock after 5 min
        private const val PBKDF2_ITERATIONS = 120_000
    }

    // Encrypted storage: attempts + lock flag survive app restart / force-close,
    // so attacker cannot reset the counter by killing the app.
    private val prefs = EncryptedSharedPreferences.create(
        context, "voice_guard_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var state: GuardState =
        if (prefs.getBoolean("hard_locked", false)) GuardState.HARD_LOCKED
        else GuardState.LOCKED_WAITING_WAKE
        private set

    private var unlockedAt = 0L

    private fun setState(s: GuardState) {
        state = s
        if (s == GuardState.UNLOCKED) unlockedAt = System.currentTimeMillis()
        onStateChange(s)
    }

    /** Call when wake word "Hey Remo" is detected (Porcupine custom keyword). */
    fun onWakeWord() {
        if (state == GuardState.LOCKED_WAITING_WAKE) setState(GuardState.WAITING_VOICE)
    }

    /** Call with the audio captured right after wake word. */
    fun onVoiceSample(pcm: ShortArray) {
        if (state != GuardState.WAITING_VOICE) return
        if (verifier.score(pcm) >= VOICE_THRESHOLD) {
            prefs.edit().putInt("fails", 0).apply()
            setState(GuardState.UNLOCKED)
        } else {
            val fails = prefs.getInt("fails", 0) + 1
            prefs.edit().putInt("fails", fails).apply()
            if (fails >= MAX_ATTEMPTS) {
                prefs.edit().putBoolean("hard_locked", true).apply()
                setState(GuardState.HARD_LOCKED)
            } else {
                setState(GuardState.LOCKED_WAITING_WAKE)
            }
        }
    }

    /** Check every time before executing a voice command. */
    fun isSessionValid(): Boolean {
        if (state != GuardState.UNLOCKED) return false
        if (System.currentTimeMillis() - unlockedAt > SESSION_TIMEOUT_MS) {
            setState(GuardState.LOCKED_WAITING_WAKE)
            return false
        }
        return true
    }

    fun lockNow() = setState(GuardState.LOCKED_WAITING_WAKE)

    // ---------- Recovery after HARD_LOCK ----------

    /** Fingerprint / Face (system biometric, strong class only). */
    fun unlockWithBiometric(activity: FragmentActivity) {
        val canAuth = BiometricManager.from(activity)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) return

        val prompt = BiometricPrompt(
            activity, ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) {
                    resetAfterRecovery()
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Voice Lock recovery")
            .setSubtitle("Fingerprint or face to unlock")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Use security question")
            .build()
        prompt.authenticate(info)
    }

    /** Save security answer once (during setup). Never store plain text. */
    fun saveSecurityAnswer(answer: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("sq_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("sq_hash", Base64.encodeToString(hash(answer, salt), Base64.NO_WRAP))
            .apply()
    }

    /** Security question fallback. Has its own limit so it can't be brute-forced. */
    fun unlockWithSecurityAnswer(answer: String): Boolean {
        val sqFails = prefs.getInt("sq_fails", 0)
        if (sqFails >= MAX_ATTEMPTS) return false   // needs biometric / device PIN

        val salt = Base64.decode(prefs.getString("sq_salt", null) ?: return false, Base64.NO_WRAP)
        val saved = Base64.decode(prefs.getString("sq_hash", null) ?: return false, Base64.NO_WRAP)

        return if (MessageDigest.isEqual(saved, hash(answer, salt))) {
            prefs.edit().putInt("sq_fails", 0).apply()
            resetAfterRecovery()
            true
        } else {
            prefs.edit().putInt("sq_fails", sqFails + 1).apply()
            false
        }
    }

    private fun resetAfterRecovery() {
        prefs.edit().putInt("fails", 0).putBoolean("hard_locked", false).apply()
        setState(GuardState.LOCKED_WAITING_WAKE)
    }

    private fun hash(answer: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(answer.trim().lowercase().toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }
}
