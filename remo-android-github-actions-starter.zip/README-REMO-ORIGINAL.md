# Remo – Voice Assistant (Tanglish)

## Folder
- `backend/`  Node.js "brain": Claude API, notes storage, Tanglish convert, tool loop
- `backend/public/`  Web client: **Laptop (Chrome/Edge), Android Chrome, iOS Safari** la work aagum
- `android/`  Kotlin core: VoiceGuard (voice lock), screen control, notifications, brain loop

## Backend run panna (laptop / server)
```
cd backend
npm install
cp .env.example .env     # ANTHROPIC_API_KEY & REMO_DEVICE_TOKEN set pannunga
npm start                # http://localhost:8787
```
Browser la http://localhost:8787 open pannunga, mic thotthu pesunga. Token first time kekkum.
Phone la use panna: backend-a **HTTPS** la deploy pannunga (mic ku HTTPS venum, localhost thavira).

## Platform: enna work aagum
| Platform | Voice Q&A, Notes | Ellaa app control | Hey Remo wake word |
|---|---|---|---|
| Android (native) | Yes | Yes (Accessibility + Notifications) | Yes (Phase 2) |
| Laptop | Yes (web) | Phase 2 (Electron + nut.js) | Phase 2 |
| iOS | Yes (Safari / Add to Home Screen) | **Illa.** iOS app-a vera app-a control panna vidaadhu | Background la illa |

iOS la Siri Shortcuts / App Intents vachi konjam app actions mattum pannalam.

## Phase 1 (indha zip la irukku)
- Backend + web client, Remo personality, notes (trash oda delete), Tanglish convert
- Android: VoiceGuard (3 attempts + lock + fingerprint/security question), open app, click/type/scroll/read screen, notification history, capability check, confirm gate

## Phase 2 (next)
1. Voice enrollment screen (Picovoice Eagle) + `SpeakerVerifier` implement
2. "Hey Remo" wake word foreground service (Porcupine custom keyword)
3. Floating Remo character (overlay + Rive/Lottie, lip-sync)
4. Composio connect (`composio_action` in server.js)
5. Capability registry UI, file read/write tools (voice verify oda)
6. Electron desktop control

## Security checklist
- API key `.env` la mattum. Git la podaadheenga. Phone app la key vaikkaadheenga
- Backend HTTPS + long random REMO_DEVICE_TOKEN
- Notes `remo-data.json` plain file. Disk encryption (BitLocker) on pannunga, backend folder-a yaarukkum share pannaadheenga. Password, card, bank details note la save pannaadheenga
- Notifications / screen text = untrusted data (prompt injection). Remo adhula irukkura instructions-a follow pannaadhu
- Delete / send / composio: confirm + voice verify kandippa
- Bank / payment apps: Remo touch pannaadhu (`DeviceTools.BLOCKED`)
- Voice mattum 100% safe illa. Sensitive actions ku fingerprint / PIN
